Thanks for downloading jumpstart!

Just a few notes:

- None of the images you can see in the demo are provided with the template, for copyright reasons. It's pretty easy to add your own though.
- In order to change the styles for the template, edit the first few lines at the top of style.css and uncomment the style you'd like to use.
- To get the contact forms working add your email address to the files contact-send.php and quick-contact.php. Assign it to the variable $YourEmailAddress 
- If you pick up any bugs in the template, you can mail us at support@codeplay.co.za

That's about it, happy coding!

contact us if you're ever in need of custom web or mobile development. We really love what we do.

Warm Regards,

Code Play studios team

Email: support@codeplay.co.za
Web: http://wwww.codeplay.co.za
Twitter: @codeplaystudios
